---
name: Bug发现与报告
about: 写一份报告来帮助我们改进
title: ''
labels: ''
assignees: ''

---

**Bug描述**
Bug的详细描述内容

**重现步骤**
1.  xxx
2.  yyy
3.  zzz
 

**软件信息**
 - 操作系统: [e.g. win10-x64]
 - FastGithub： [e.g.  v2.0.0]
